mkdir artifacts
cd code
zip ../artifacts/lambda_function.zip lambda_function.py