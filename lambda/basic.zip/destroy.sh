cd terraform

# Set TF_LOG to DEBUG
# export TF_LOG=DEBUG

# Run Terraform commands (e.g., plan, apply, etc.)
terraform destroy

# Unset TF_LOG after you're done
# unset TF_LOG

cd ..