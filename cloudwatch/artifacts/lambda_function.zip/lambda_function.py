import json
import os


def lambda_handler(event, context):
    print(event)
    print(context)